<?php
return array(
    'name'        => 'Оплата картой',
    'description' => 'Прием платежей картой',
    'icon'        => 'img/card.png',
    'logo'        => 'img/card.png',
    'vendor'      => 'webasyst',
    'version'     => '1.0.0',
);