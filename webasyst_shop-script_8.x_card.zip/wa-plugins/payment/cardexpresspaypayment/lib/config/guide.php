<?php

return array(
    array(
        'value'       => '%HTTPS_RELAY_URL%?action=notify&app_id=%APP_ID%_%MERCHANT_ID%',
        'title'       => 'Invoice Confirmation URL',
        'description' => 'URL(https), на который отправляется запрос «Проверка заказа».<br>
<strong>Указанный в этом поле адрес скопируйте и сохраните в соответствующем поле внутри вашего аккаунта Express Pay.</strong>',
    ),
);